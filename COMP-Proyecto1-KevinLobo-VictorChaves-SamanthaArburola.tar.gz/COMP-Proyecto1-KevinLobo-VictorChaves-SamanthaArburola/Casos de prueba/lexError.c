int main(){

	int keyword = @-);
	
}
	