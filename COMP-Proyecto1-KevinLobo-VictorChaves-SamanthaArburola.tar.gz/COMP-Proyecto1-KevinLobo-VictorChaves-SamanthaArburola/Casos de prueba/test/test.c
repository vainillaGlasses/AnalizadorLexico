//Prueba de Comentario
#include "test2.h"
#define Z H + H
#define H 25
#define H 50
#define U Z + H
#define Zero 0
#define B Zero
/*Prueba de comentario*/
int main(){
	char *string = "HOLA";
	int zero = Zero;
	int hola = HOLA;
	int hola2 = HOLA;
	int try = Z;
	int try2 = U;
	//Prueba de Comentario
	/*Prueba de comentario*/
	int x = H;
	#define H 27
	int s = H;
	int b = B;
	#define ADIOS 35
	return 0;
//Prueba de Comentario
/*Prueba de comentario*/
}

int = H;

//Prueba de Comentario
/*Prueba de comentario*/